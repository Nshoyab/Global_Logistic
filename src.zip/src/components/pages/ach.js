import React from "react";
import './achivement.css';

function Ach(props){
    return(
        <>

      <img src={props.Ach} className="img-thumbnail" alt="..."/>

        </>
        
     );}
export default Ach;